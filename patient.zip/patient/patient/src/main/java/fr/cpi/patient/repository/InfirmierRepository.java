package fr.cpi.patient.repository;

import fr.cpi.patient.demo_models.InfirmierModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Repository
public class InfirmierRepository {

    @Autowired
    private WebClient webClient;

    public Mono<InfirmierModel> getInfirmierById(String id){
        Mono<InfirmierModel> infirmier = webClient.get()
                .uri("/infirmier/"+id)
                .retrieve()
                .bodyToMono(InfirmierModel.class);
        return infirmier;
    }
}
