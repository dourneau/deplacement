package fr.cpi.patient.service;


import fr.cpi.patient.demo_models.InfirmierModel;
import fr.cpi.patient.demo_models.PatientInfirmier;
import fr.cpi.patient.demo_models.PatientModel;
import fr.cpi.patient.repository.InfirmierRepository;
import fr.cpi.patient.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@Service
public class PatientService {

    @Autowired
    PatientRepository repository;

    @Autowired
    InfirmierRepository infirmierRepository;

    public List<PatientModel> findAll(){
        return repository.findAll();
    }

    public PatientInfirmier findOne(String id) {
        //Recuperation du patient
        Optional<PatientModel> patient = repository.findById(id);
        //recuperation de l'id de l'infirmier
        //On le met a null si on ne recupere rien
        PatientInfirmier patientInfirmier = null;
        if (patient.isPresent()) {
            //mappage de  l'optionnal en patient (avec le .get().get...)
            String idInfirmier = patient.get().getIdInfirmier();
            //Call du microservice infirmier
            Mono<InfirmierModel> infirmier = infirmierRepository.getInfirmierById(idInfirmier);
            //fusion des datas
            //On creer un patientavecInfosInfirmier ou on met infirmieret le patient mappés.
            patientInfirmier = new PatientInfirmier(infirmier.block(), patient.get());
        }
        return patientInfirmier;
    }

    public List<PatientModel> findAllByInfirmier(String id){
        return repository.findAllByIdInfirmier(id);
    }

    //ajout
    public PatientModel save(PatientModel patient){
        return repository.save(patient);
    }

    //update
    public PatientModel update(PatientModel patient){
        return repository.save(patient);
    }

    public void delete(String id) {
        repository.deleteById(id);
    }
}
