package fr.cpi.patient.demo_models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PatientInfirmier {
    private InfirmierModel infirmier;
    private PatientModel patient;


}
