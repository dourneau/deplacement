package fr.cpi.patient.demo_models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdressModel {
    private String numero;
    private String rue;
    private int cp;
    private String ville;
}
