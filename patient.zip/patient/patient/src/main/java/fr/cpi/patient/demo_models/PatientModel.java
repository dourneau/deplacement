package fr.cpi.patient.demo_models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@Document("patient")
@NoArgsConstructor
@AllArgsConstructor
public class PatientModel {
    @Id
    private String id;
    private String nom;
    private String prenom;
    private Date naissance;
    private String sexe;
    private Long securite_sociale;
    private String idInfirmier;
    private AdressModel adress;
}