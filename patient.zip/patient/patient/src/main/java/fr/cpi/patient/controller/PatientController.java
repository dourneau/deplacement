package fr.cpi.patient.controller;

import fr.cpi.patient.demo_models.PatientInfirmier;
import fr.cpi.patient.demo_models.PatientModel;
import fr.cpi.patient.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("patient")
public class PatientController {

    @Autowired
    PatientService service;

    @GetMapping()
    @ResponseStatus(HttpStatus.OK)
    public List<PatientModel> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public PatientInfirmier findOne(@PathVariable String id){
        return service.findOne(id);
    }

    @GetMapping("/infirmier/{idInfirmier}")
    public List<PatientModel> findAllByIdInfirmier(@PathVariable String idInfirmier) {
        return service.findAllByInfirmier(idInfirmier);
    }

    @PostMapping()
    public PatientModel create(@RequestBody PatientModel patient ) {
        return service.save(patient);
    }

    @PutMapping()
    public PatientModel update(@RequestBody PatientModel patient ) {
        return service.save(patient);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable String id) {
        service.delete(id);
        return ResponseEntity.ok("patient supprimé");
    }
}