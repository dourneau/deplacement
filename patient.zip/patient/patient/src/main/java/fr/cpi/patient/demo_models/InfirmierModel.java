package fr.cpi.patient.demo_models;

public class InfirmierModel {
    private String nom;
    private String prenom;
}
