package fr.cpi.infirmier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfirmierApplicationTests {

	@Test
	void contextLoads() {
	}

}
