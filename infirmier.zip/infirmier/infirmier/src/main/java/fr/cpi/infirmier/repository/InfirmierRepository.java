package fr.cpi.infirmier.repository;

import fr.cpi.infirmier.demo_models.InfirmierModel;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface InfirmierRepository extends MongoRepository<InfirmierModel,String> {
}
