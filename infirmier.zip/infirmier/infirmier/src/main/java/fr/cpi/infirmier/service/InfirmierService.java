package fr.cpi.infirmier.service;

import fr.cpi.infirmier.demo_models.InfirmierModel;
import fr.cpi.infirmier.demo_models.InfirmierPatientModel;
import fr.cpi.infirmier.demo_models.PatientModel;
import fr.cpi.infirmier.repository.InfirmierRepository;
import fr.cpi.infirmier.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@Service
public class InfirmierService {
    @Autowired
    InfirmierRepository repository;

    @Autowired
    PatientRepository patientRepository;

    public List<InfirmierModel> findAll(){
        return repository.findAll();
    }

    public InfirmierPatientModel findOne(String id){
        // recuperer un infirmier
        Optional<InfirmierModel> infirmier = repository.findById(id);
        // recuperer tous les patients de l'infimier
        List<PatientModel> patientsList = null;

        InfirmierPatientModel infirmierPatient = null;
        if (infirmier.isPresent()) {
            Flux<PatientModel> patients = patientRepository.findAll(id);
            Mono<List<PatientModel>> patientMono = patients.collectList();
            patientsList = patientMono.block();

            infirmierPatient = new InfirmierPatientModel(infirmier.get(), patientsList);
            System.out.println(infirmierPatient);
        }

        return infirmierPatient;
    }

    //ajout
    public InfirmierModel save(InfirmierModel infirmier){
        return repository.save(infirmier);
    }

    //update
    public InfirmierModel update(InfirmierModel infirmier){
        return repository.save(infirmier);
    }

    public void delete(String id) {
        repository.deleteById(id);
    }

}