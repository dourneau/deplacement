package fr.cpi.infirmier.controller;

import fr.cpi.infirmier.demo_models.InfirmierModel;
import fr.cpi.infirmier.demo_models.InfirmierPatientModel;
import fr.cpi.infirmier.demo_models.PatientModel;
import fr.cpi.infirmier.service.InfirmierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("infirmier")
public class InfirmierController {

    @Autowired
    InfirmierService service;

    @GetMapping()
    @ResponseStatus(HttpStatus.OK)
    public List<InfirmierModel> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public InfirmierPatientModel findOne(@PathVariable String id){
        return service.findOne(id);
    }

    @PostMapping()
    public InfirmierModel create(@RequestBody InfirmierModel infirmier ) {
        return service.save(infirmier);
    }

    @PutMapping()
    public InfirmierModel update(@RequestBody InfirmierModel infirmier ) {
        return service.save(infirmier);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable String id) {
        service.delete(id);
        return ResponseEntity.ok("infirmier supprimé");
    }

}
