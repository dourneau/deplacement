package fr.cpi.infirmier.demo_models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PatientModel {
    private String nom;
    private String prenom;
    private String sexe;
    private Long securite_sociale;
}
