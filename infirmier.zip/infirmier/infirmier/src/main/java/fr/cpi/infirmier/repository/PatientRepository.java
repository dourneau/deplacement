package fr.cpi.infirmier.repository;

import fr.cpi.infirmier.demo_models.PatientModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

@Repository
public class PatientRepository {

    @Autowired
    private WebClient webClient;

    public Flux<PatientModel> findAll(String id){

        Flux<PatientModel> patients = webClient.get()
                .uri("/patient/infirmier/" + id)
                .retrieve()
                .bodyToFlux(PatientModel.class);
        return patients;
    }
}
