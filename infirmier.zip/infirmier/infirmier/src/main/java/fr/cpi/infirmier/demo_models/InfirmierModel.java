package fr.cpi.infirmier.demo_models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document("infirmier")
@NoArgsConstructor
@AllArgsConstructor
public class InfirmierModel {

    @Id
    private String id;
    private String nom;
    private String prenom;
    private Long numero_pro;
    private int tel_pro;
    private int tel_perso;
    private AdressModel adress;





}
