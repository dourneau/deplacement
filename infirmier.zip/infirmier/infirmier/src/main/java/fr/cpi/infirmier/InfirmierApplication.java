package fr.cpi.infirmier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfirmierApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfirmierApplication.class, args);
	}

}
